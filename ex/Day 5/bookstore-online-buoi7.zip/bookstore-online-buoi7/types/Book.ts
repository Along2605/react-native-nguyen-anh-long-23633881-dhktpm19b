export interface Book {
  id: number;
  title: string;
  author: string;
  price: number;
  cover: string; // URL ảnh bìa — dùng cho Image ở BookCard (Buổi 6)
  inStock?: boolean; // thuộc tính tuỳ chọn
  readonly isbn: string; // không thể gán lại sau khi tạo
}

export const sampleBook: Book = {
  id: 1,
  title: "Dế Mèn Phiêu Lưu Ký",
  author: "Tô Hoài",
  price: 45000,
  cover: "https://picsum.photos/seed/book1/200/300",
  isbn: "978-604-0-00001-1",
};

export let bookTitle: string = "Nhà Giả Kim";
export let price: number = 89000;
export let inStock: boolean = true;
export let tags: string[] = ["Tiểu thuyết", "Triết lý"];

export enum BookStatus {
  Available,
  OutOfStock,
  PreOrder,
}
