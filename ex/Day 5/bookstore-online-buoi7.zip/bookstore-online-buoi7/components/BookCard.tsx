import React from "react";
import { Pressable, Text, Image, View, StyleSheet } from "react-native";
import { Book } from "../types/Book";

interface BookCardProps {
  book: Book;
  onPress: (id: number) => void;
  // Giữ lâu để mở Modal "Xem nhanh" (bổ sung từ hoạt động Component Bingo, Buổi 6).
  onLongPress?: (id: number) => void;
}

export function BookCard({ book, onPress, onLongPress }: BookCardProps) {
  return (
    <Pressable
      style={styles.card}
      onPress={() => onPress(book.id)}
      onLongPress={onLongPress ? () => onLongPress(book.id) : undefined}
    >
      <Image source={{ uri: book.cover }} style={styles.cover} />
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={2}>
          {book.title}
        </Text>
        <Text style={styles.author}>{book.author}</Text>
        <Text style={styles.price}>{book.price.toLocaleString()} đ</Text>
        {!book.inStock && <Text style={styles.outOfStock}>Hết hàng</Text>}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: "row", padding: 12, gap: 12, alignItems: "center" },
  cover: { width: 64, height: 90, borderRadius: 6, backgroundColor: "#EEF2F7" },
  info: { flex: 1, gap: 2 },
  title: { fontSize: 15, fontWeight: "700" },
  author: { fontSize: 12, color: "#5B6B7F" },
  price: { fontSize: 13, fontWeight: "600", color: "#3178C6" },
  outOfStock: { fontSize: 11, color: "#D64545", fontWeight: "600" },
});
