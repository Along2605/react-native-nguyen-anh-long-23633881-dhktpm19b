// Copy vào: <dự án>/utils/cart.ts
import { Book } from "../types/Book";

export function addToCart(book: Book, quantity: number = 1): void {
  console.log(`Đã thêm ${quantity} x ${book.title}`);
}

export type OnPress = (id: number) => void;

export interface ButtonProps {
  label: string;
  onPress: OnPress;
}

// Generic function — Tiết 6
export function getFirstItem<T>(arr: T[]): T {
  return arr[0];
}

// Generic interface — dùng lại ở Buổi 4 (gọi API) và Buổi 7
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}
