import React, { useState } from "react";
import {
  View,
  FlatList,
  TextInput,
  StyleSheet,
  Text,
  Modal,
  Pressable,
  Alert,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { BookCard } from "../components/BookCard";
import { useBooks } from "../hooks/useBooks";
import { Book } from "../types/Book";

export function BookListScreen() {
  // Toàn bộ logic gọi API nằm trong hook — screen chỉ đọc kết quả.
  const { books, loading, refreshing, error, reload } = useBooks();
  const [query, setQuery] = useState("");
  const [quickViewBook, setQuickViewBook] = useState<Book | null>(null);

  const filtered = books.filter((b) => b.title.toLowerCase().includes(query.toLowerCase()));

  function handleConfirmPurchase() {
    if (!quickViewBook) return;
    const bookTitle = quickViewBook.title;
    setQuickViewBook(null);
    Alert.alert("Xác nhận mua", `Mua "${bookTitle}" với giá ${quickViewBook.price.toLocaleString()} đ?`, [
      { text: "Huỷ", style: "cancel" },
      { text: "Mua", onPress: () => Alert.alert("Thành công", `Đã đặt mua "${bookTitle}"!`) },
    ]);
  }

  // Chọn nội dung theo trạng thái dữ liệu. Thứ tự kiểm tra quan trọng:
  function renderBody() {
    // 1) Đang tải lần đầu, hoặc bấm "Thử lại" khi chưa có sách nào -> vòng xoay.
    if (loading || (refreshing && books.length === 0)) {
      return (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#3178C6" />
          <Text style={styles.hint}>Đang tải sách...</Text>
        </View>
      );
    }
    // 2) Lỗi mà chưa có gì để hiện -> thông báo + nút thử lại.
    if (error && books.length === 0) {
      return (
        <View style={styles.center}>
          <Text style={styles.errorText}>{error}</Text>
          <Pressable style={styles.retryButton} onPress={reload}>
            <Text style={styles.retryText}>Thử lại</Text>
          </Pressable>
        </View>
      );
    }
    // 3) Có dữ liệu. Nếu tải lại thất bại thì vẫn giữ danh sách cũ + hiện 1 dòng báo lỗi.
    return (
      <>
        {error && <Text style={styles.banner}>{error}</Text>}
        <FlatList
          data={filtered}
          keyExtractor={(b) => String(b.id)}
          renderItem={({ item }) => (
            <BookCard
              book={item}
              onPress={(id) => console.log("Mở sách", id)}
              onLongPress={() => setQuickViewBook(item)}
            />
          )}
          ListEmptyComponent={<Text style={styles.empty}>Không tìm thấy sách nào</Text>}
          // Kéo xuống để tải lại (chỉ có trên điện thoại; trên web là no-op)
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={reload} />}
        />
      </>
    );
  }

  return (
    <View style={styles.container}>
      <TextInput placeholder="Tìm sách..." value={query} onChangeText={setQuery} style={styles.search} />

      {renderBody()}

      <Modal
        visible={quickViewBook !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setQuickViewBook(null)}
      >
        <View style={styles.backdrop}>
          <View style={styles.sheet}>
            {quickViewBook && (
              <>
                <Text style={styles.sheetTitle}>{quickViewBook.title}</Text>
                <Text style={styles.sheetAuthor}>{quickViewBook.author}</Text>
                <Text style={styles.sheetPrice}>{quickViewBook.price.toLocaleString()} đ</Text>
                {!quickViewBook.inStock && <Text style={styles.sheetOutOfStock}>Hiện đang hết hàng</Text>}

                <View style={styles.sheetActions}>
                  <Pressable
                    style={[styles.sheetButton, styles.sheetButtonSecondary]}
                    onPress={() => setQuickViewBook(null)}
                  >
                    <Text style={styles.sheetButtonSecondaryText}>Đóng</Text>
                  </Pressable>
                  <Pressable style={[styles.sheetButton, styles.sheetButtonPrimary]} onPress={handleConfirmPurchase}>
                    <Text style={styles.sheetButtonPrimaryText}>Mua ngay</Text>
                  </Pressable>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12 },
  search: {
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  empty: { textAlign: "center", color: "#5B6B7F", marginTop: 24 },

  // Trạng thái tải / lỗi: căn giữa phần còn lại của màn hình
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  hint: { color: "#5B6B7F" },
  errorText: { color: "#D64545", textAlign: "center", paddingHorizontal: 24 },
  retryButton: { backgroundColor: "#3178C6", paddingHorizontal: 22, paddingVertical: 10, borderRadius: 10 },
  retryText: { color: "#FFFFFF", fontWeight: "700" },
  banner: {
    backgroundColor: "#FDECEC",
    color: "#D64545",
    padding: 8,
    borderRadius: 8,
    marginBottom: 8,
    textAlign: "center",
  },

  backdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.4)" },
  sheet: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 20,
    gap: 4,
  },
  sheetTitle: { fontSize: 18, fontWeight: "800", color: "#111827" },
  sheetAuthor: { fontSize: 13, color: "#5B6B7F" },
  sheetPrice: { fontSize: 16, fontWeight: "700", color: "#3178C6", marginTop: 4 },
  sheetOutOfStock: { fontSize: 12, color: "#D64545", fontWeight: "600", marginTop: 2 },
  sheetActions: { flexDirection: "row", gap: 10, marginTop: 16 },
  sheetButton: { flex: 1, paddingVertical: 12, borderRadius: 10, alignItems: "center" },
  sheetButtonSecondary: { backgroundColor: "#F1F5F9" },
  sheetButtonSecondaryText: { color: "#374151", fontWeight: "600" },
  sheetButtonPrimary: { backgroundColor: "#3178C6" },
  sheetButtonPrimaryText: { color: "#FFFFFF", fontWeight: "700" },
});
