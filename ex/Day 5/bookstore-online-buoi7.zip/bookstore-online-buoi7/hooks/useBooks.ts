import { useCallback, useEffect, useState } from "react";
import { Book } from "../types/Book";
import { getBooks } from "../services/api";

export function useBooks() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      const data = await getBooks();
      setBooks(data);
    } catch (e) {
      setError("Không tải được danh sách sách. Vui lòng thử lại.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const reload = () => {
    setRefreshing(true);
    load();
  };

  return { books, loading, refreshing, error, reload };
}
