import axios from "axios";
import { Book } from "../types/Book";
import { ApiResponse } from "../utils/cart";

// mọi lời gọi sau chỉ cần viết đường dẫn ngắn ("/products").
export const api = axios.create({
  baseURL: "https://fakestoreapi.com",
  timeout: 10000, // quá 10 giây không thấy phản hồi -> ném lỗi, tránh chờ vô hạn
});

// Token đăng nhập giữ ở biến module; interceptor bên dưới tự gắn vào MỌI request,
let authToken: string | null = null;
export function setAuthToken(token: string) {
  authToken = token;
}

api.interceptors.request.use((config) => {
  if (authToken) {
    config.headers.Authorization = `Bearer ${authToken}`;
  }
  return config;
});

// ---- Ánh xạ dữ liệu của ứng dụng ----------------------------------
// fakestoreapi.com trả về SẢN PHẨM ({ image, category, rating... }), không phải
// Book ({ cover, author, isbn... }). 
interface ProductDTO {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: { rate: number; count: number };
}

// API trả giá bằng USD, còn giao diện hiển thị VND -> đổi ở tầng ánh xạ, không
// đổi trong component. Tỉ giá cố định chỉ để minh hoạ.
const USD_TO_VND = 25000;

function toBook(p: ProductDTO): Book {
  return {
    id: p.id,
    title: p.title,
    author: p.category, // API không có tác giả -> dùng tạm danh mục làm dòng phụ
    price: Math.round((p.price * USD_TO_VND) / 1000) * 1000, // làm tròn tới nghìn đồng
    cover: p.image,
    inStock: true, // API không có tồn kho -> coi như còn hàng
    isbn: String(p.id),
  };
}

export async function getBooks(page = 1): Promise<Book[]> {
  // API có thể trả mảng hoặc bọc trong ApiResponse<T> (Buổi 2) -> xử lý cả 2.
  const { data } = await api.get<ApiResponse<ProductDTO[]> | ProductDTO[]>("/products", {
    params: { page },
  });
  const products = Array.isArray(data) ? data : data.data;
  return products.map(toBook);
}
