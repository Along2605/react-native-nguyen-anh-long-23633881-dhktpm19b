# Trả lời câu hỏi bổ sung – Buổi 7

## 1. Cấu trúc điều hướng
BookDetail được đăng ký ở Stack (bên ngoài Tab) nên khi mở, màn Chi tiết được đặt chồng lên trên cả màn Tabs: Tab Bar bị che đi và header tự có nút ← để quay về đúng chỗ cũ (vị trí cuộn của Home vẫn giữ). Nếu đặt BookDetail vào Tab thì nó trở thành một tab ngang hàng với Home/Giỏ hàng: Tab Bar vẫn hiện ở dưới, có thêm một nút tab thừa, không có nút ← và cũng không có "chồng màn" để quay lại.

## 2. Redux
Redux Toolkit dùng thư viện Immer: trong reducer ta sửa trên một bản nháp (draft), viết `state.items.push(...)` như đang mutate, còn Immer ghi lại các thay đổi rồi tạo ra một state mới bất biến, state cũ không bị đụng tới. Bỏ `useMemo` trong `useCart` thì tổng tiền/tổng số lượng vẫn hiển thị đúng, vì `reduce` vẫn chạy; khác biệt là phép tính bị chạy lại ở mọi lần render (kể cả khi `items` không đổi), giỏ càng lớn càng tốn. `useMemo` chỉ để tối ưu, không quyết định đúng hay sai.

## 3. Promise.all
`Promise.all` sẽ lỗi cả nhóm khi chỉ một promise lỗi, nên nếu `getCategories()` lỗi thì nhảy vào `catch` và Home hiện ErrorView dù sách đã tải được. Dùng `Promise.allSettled` thì đợi cả hai xong và trả về trạng thái từng cái (`fulfilled` / `rejected`), nhờ vậy vẫn hiện được danh sách sách, chỉ thiếu chip danh mục. Đánh đổi: phải tự kiểm tra và xử lý lỗi cho từng phần, code dài hơn và giao diện phải chấp nhận trạng thái "thiếu một nửa dữ liệu".

```ts
const [b, c] = await Promise.allSettled([getBooks(), getCategories()]);
if (b.status === "fulfilled") setBooks(b.value); else setError(getErrorMessage(b.reason));
if (c.status === "fulfilled") setCategories(c.value); // lỗi danh mục: chỉ ẩn chip
```

## 4. Debounce
Nếu gọi `setTimeout` thẳng trong `onChangeText` thì mỗi phím gõ tạo một hẹn giờ riêng và không có ai huỷ hẹn giờ cũ, nên gõ 10 ký tự vẫn lọc 10 lần (chỉ là bị trễ 400 ms). Đặt trong `useEffect` có hàm dọn dẹp `return () => clearTimeout(t)` thì mỗi lần `value` đổi, hẹn giờ trước bị huỷ, chỉ lần gõ cuối được áp dụng. Hàm dọn dẹp cũng tránh lỗi gọi `setState` sau khi component đã bị gỡ (unmount).

## 5. Code bổ sung – sắp xếp theo giá
Thêm một state `sort` và sửa `visibleBooks` trong `HomeScreen.tsx` (nút "Giá ↑" / "Giá ↓", bấm lần nữa để bỏ):

```tsx
const [sort, setSort] = useState<SortOrder>(null); // "asc" | "desc" | null

const visibleBooks = useMemo(() => {
  const filtered = filterBooks(books, { keyword: debouncedKeyword, categoryId, priceRange });
  if (sort === null) return filtered;
  // sắp xếp trên BẢN SAO để không sửa mảng books gốc
  return [...filtered].sort((a, b) => (sort === "asc" ? a.price - b.price : b.price - a.price));
}, [books, debouncedKeyword, categoryId, priceRange, sort]);
```
